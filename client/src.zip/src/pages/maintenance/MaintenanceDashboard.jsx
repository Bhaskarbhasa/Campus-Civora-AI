import DashboardLayout from '../../components/layout/DashboardLayout';
export default function MaintenanceDashboard() {
  return (
    <DashboardLayout title="Maintenance Supervisor" subtitle="Assign and manage work orders">
      <div style={{ textAlign: 'center', padding: 80, color: 'var(--text-muted)' }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>🏗️</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 10 }}>Maintenance Dashboard</h2>
        <p>Use the "All Complaints" link in the sidebar to view and assign complaints to technicians.</p>
      </div>
    </DashboardLayout>
  );
}
