import DashboardLayout from '../../components/layout/DashboardLayout';
export default function AnalyticsPage() {
  return (
    <DashboardLayout title="Analytics" subtitle="Campus-wide insights">
      <div style={{ textAlign: 'center', padding: 80, color: 'var(--text-muted)' }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>📊</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 10 }}>Analytics Dashboard</h2>
        <p>Full analytics are available in the Admin Dashboard.</p>
      </div>
    </DashboardLayout>
  );
}
