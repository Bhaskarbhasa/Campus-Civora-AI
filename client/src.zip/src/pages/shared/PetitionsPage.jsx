// Placeholder pages for App.jsx lazy imports - these show a shimmer loader until implementation is complete
import DashboardLayout from '../../components/layout/DashboardLayout';

export default function PetitionsPage() {
  return (
    <DashboardLayout title="Petitions" subtitle="Community petitions and demands">
      <div style={{ textAlign: 'center', padding: 80, color: 'var(--text-muted)' }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>✊</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 10 }}>Petitions Coming Soon</h2>
        <p>This module is being finalized. All petition data is ready in the backend.</p>
      </div>
    </DashboardLayout>
  );
}
