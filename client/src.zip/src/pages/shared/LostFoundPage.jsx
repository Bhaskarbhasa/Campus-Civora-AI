import DashboardLayout from '../../components/layout/DashboardLayout';
export default function LostFoundPage() {
  return (
    <DashboardLayout title="Lost & Found" subtitle="Report and find lost items">
      <div style={{ textAlign: 'center', padding: 80, color: 'var(--text-muted)' }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>🔍</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 10 }}>Lost & Found Coming Soon</h2>
        <p>This module is being finalized. AI-powered matching is available in the backend.</p>
      </div>
    </DashboardLayout>
  );
}
