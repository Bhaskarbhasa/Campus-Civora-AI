import DashboardLayout from '../../components/layout/DashboardLayout';
export default function PollsPage() {
  return (
    <DashboardLayout title="Polls" subtitle="Campus polls and voting">
      <div style={{ textAlign: 'center', padding: 80, color: 'var(--text-muted)' }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>🗳️</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 10 }}>Polls Coming Soon</h2>
        <p>This module is being finalized. All poll data is ready in the backend.</p>
      </div>
    </DashboardLayout>
  );
}
