const { Ollama } = require('ollama');

const ollama = new Ollama({ host: process.env.OLLAMA_BASE_URL || 'http://localhost:11434' });
const MODEL = process.env.OLLAMA_MODEL || 'llama3';

const isOllamaAvailable = async () => {
  try {
    await ollama.list();
    return true;
  } catch {
    return false;
  }
};

const analyzeComplaint = async (complaint) => {
  const fallback = {
    suggestedCategory: complaint.category,
    suggestedDepartment: getDepartmentFromCategory(complaint.category),
    predictedPriority: 'medium',
    sentimentScore: 0.5,
    isDuplicate: false,
    summary: complaint.description.substring(0, 100),
    confidence: 0.5,
    processed: false,
  };

  try {
    const available = await isOllamaAvailable();
    if (!available) return fallback;

    const prompt = `You are an AI assistant for Campus CIVORA AI at Amrita Vishwa Vidyapeetham university.
Analyze this student complaint and respond ONLY with valid JSON (no markdown, no extra text):

Complaint Title: ${complaint.title}
Description: ${complaint.description}
Category Selected by Student: ${complaint.category}
Location: ${complaint.location?.building || 'Not specified'}, ${complaint.location?.room || ''}

Respond with this exact JSON structure:
{
  "suggestedCategory": "one of: electrical|plumbing|internet_connectivity|classroom_equipment|laboratory_equipment|hostel_facilities|transportation|food_services|security|housekeeping|academic_grievance|examination|library|sports_facilities|medical|civil_maintenance|general_administration|other",
  "suggestedDepartment": "responsible department name",
  "predictedPriority": "one of: low|medium|high|emergency",
  "sentimentScore": 0.0 to 1.0 (0=calm, 1=very urgent/angry/dangerous),
  "summary": "2 sentence admin summary",
  "confidence": 0.0 to 1.0,
  "isEmergency": true or false
}`;

    const response = await ollama.chat({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      options: { temperature: 0.1 },
    });

    const content = response.message.content.trim();
    // Extract JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return { ...fallback, processed: false };

    const parsed = JSON.parse(jsonMatch[0]);
    return {
      suggestedCategory: parsed.suggestedCategory || complaint.category,
      suggestedDepartment: parsed.suggestedDepartment || getDepartmentFromCategory(complaint.category),
      predictedPriority: parsed.predictedPriority || 'medium',
      sentimentScore: parsed.sentimentScore || 0.5,
      isDuplicate: false,
      summary: parsed.summary || complaint.description.substring(0, 100),
      confidence: parsed.confidence || 0.7,
      isEmergency: parsed.isEmergency || false,
      processed: true,
    };
  } catch (error) {
    console.warn(`⚠️  Ollama AI analysis failed: ${error.message}. Using fallback.`);
    return fallback;
  }
};

const checkDuplicate = async (newComplaint, recentComplaints) => {
  if (!recentComplaints || recentComplaints.length === 0) return null;
  try {
    const available = await isOllamaAvailable();
    if (!available) return null;

    const recentList = recentComplaints.slice(0, 5).map((c, i) =>
      `${i + 1}. [ID: ${c._id}] Category: ${c.category}, Location: ${c.location?.building}, Title: ${c.title}`
    ).join('\n');

    const prompt = `You are checking if a new complaint is a duplicate of existing ones.
New complaint: Category: ${newComplaint.category}, Location: ${newComplaint.location?.building} ${newComplaint.location?.room}, Title: ${newComplaint.title}, Description: ${newComplaint.description.substring(0, 200)}

Recent complaints in same area:
${recentList}

Is the new complaint a duplicate of any existing one? Respond ONLY with JSON:
{"isDuplicate": true or false, "duplicateOfIndex": 1-based index number or null, "reason": "brief reason"}`;

    const response = await ollama.chat({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      options: { temperature: 0.1 },
    });

    const jsonMatch = response.message.content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;

    const parsed = JSON.parse(jsonMatch[0]);
    if (parsed.isDuplicate && parsed.duplicateOfIndex) {
      const idx = parseInt(parsed.duplicateOfIndex) - 1;
      if (recentComplaints[idx]) return recentComplaints[idx]._id;
    }
    return null;
  } catch {
    return null;
  }
};

const analyzePetition = async (petition) => {
  try {
    const available = await isOllamaAvailable();
    if (!available) return { summary: petition.description.substring(0, 100), isDuplicate: false };

    const prompt = `Summarize this university petition in 3 sentences for administrators. 
Title: ${petition.title}
Description: ${petition.description}
Purpose: ${petition.purpose}
Respond ONLY with JSON: {"summary": "3 sentence summary", "tags": ["tag1","tag2","tag3"]}`;

    const response = await ollama.chat({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      options: { temperature: 0.3 },
    });

    const jsonMatch = response.message.content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return { summary: petition.description.substring(0, 100), isDuplicate: false };

    const parsed = JSON.parse(jsonMatch[0]);
    return { summary: parsed.summary, tags: parsed.tags || [], isDuplicate: false };
  } catch {
    return { summary: petition.description.substring(0, 100), isDuplicate: false };
  }
};

const matchLostFound = async (lostItem, foundItems) => {
  if (!foundItems || foundItems.length === 0) return [];
  try {
    const available = await isOllamaAvailable();
    if (!available) return [];

    const foundList = foundItems.slice(0, 5).map((f, i) =>
      `${i + 1}. [ID: ${f._id}] Category: ${f.itemCategory}, Description: ${f.description}, Location: ${f.foundLocation}`
    ).join('\n');

    const prompt = `Match this lost item against found items. 
Lost: Category: ${lostItem.itemCategory}, Description: ${lostItem.description}, Color: ${lostItem.color}, Brand: ${lostItem.brand}

Found items:
${foundList}

Which found items potentially match? Respond ONLY with JSON:
{"matches": [{"index": 1-based index, "score": 0.0-1.0, "reason": "why they match"}]}`;

    const response = await ollama.chat({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      options: { temperature: 0.2 },
    });

    const jsonMatch = response.message.content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return [];

    const parsed = JSON.parse(jsonMatch[0]);
    return (parsed.matches || [])
      .filter((m) => m.score >= 0.6)
      .map((m) => ({
        matchedReportId: foundItems[parseInt(m.index) - 1]?._id,
        matchScore: m.score,
      }))
      .filter((m) => m.matchedReportId);
  } catch {
    return [];
  }
};

const getDepartmentFromCategory = (category) => {
  const map = {
    electrical: 'Electrical Maintenance',
    plumbing: 'Plumbing & Civil',
    internet_connectivity: 'IT Department',
    classroom_equipment: 'Academic Affairs',
    laboratory_equipment: 'Laboratory Management',
    hostel_facilities: 'Hostel Administration',
    transportation: 'Transport Department',
    food_services: 'Mess & Canteen',
    security: 'Security Department',
    housekeeping: 'Housekeeping',
    academic_grievance: 'Academic Affairs',
    examination: 'Examination Cell',
    library: 'Library',
    sports_facilities: 'Sports Department',
    medical: 'Medical Center',
    civil_maintenance: 'Civil Maintenance',
    general_administration: 'Administration',
    other: 'Administration',
  };
  return map[category] || 'Administration';
};

module.exports = { analyzeComplaint, checkDuplicate, analyzePetition, matchLostFound, getDepartmentFromCategory };
